class UsersModel {
  final String username;
  final String password;

  UsersModel({required this.username, required this.password});
}
